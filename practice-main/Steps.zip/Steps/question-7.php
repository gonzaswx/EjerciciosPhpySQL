<?php
/**
 * Siguiendo el principio de responsabilidad Única (SRP) que es la S del Principio SOLID
 * donde nos dice que una clase debe tener un único motivo por el cual debe ser modificada:
 * Qué cambios le harías a esta clase?
 */


class Product
{
    private $name;

    public function getName($name): string
    {
        return $this->$name;
    }

    public function JsonProductFormatter(Product $product): string
    {

        return json_encode([
            "name"=> $product->getName()
        ]);
    }
}


$product = new Product ('Laptop');
echo $product->JsonProductFormatter();

//Product ahora se encargara de almacenary recuperar informacion del producto

//JsonProductFormatter se encargara de tomar una instancia de Product y formatearla en JSON.
