<?php
/**
 * La interface de usuarios contiene dos tipos de controles de entrada.
 * TextInput, acepta todos los tipos
 * NumericInput que solo acepta dígitos.
 * Implemente la clase TextInput que contenga:
 * - Un método add($text) que agrega el texto dado al actual valor
 * - Un método getValue() que devuelva el actual valor
 *
 * Implemente la clase NumericInput que contenga:
 * - Hereda de TextInput
 * - El método add ignorará todo parámetro $text que no sea numérico
 */

class TextInput
{
    //almacene el valor actual del valor dado en la entrada
    private $value = '';


    //agregue el texto al valor dado
    public funtion add($text){
        $this->value .= $text;
    }

    public function getvalue(){
        return $this->value;
}
}



class NumericInput
{
    public function add($text){
        $numericText = preg_replace('/\D','', $text);
        parent::add($numericText);
    }
}

$textinput = new TextInput('');
$textinput->add('Hello');
$textinput->add('123');
echo "TestInput Value: " . $textinput->getvalue() ."\n";

$numericInput = new NumericInput("");
$numericInput->add("Hello");
$numericInput->add("abc456");
echo "NumericInput Value: " . $numericInput->getvalue() ."\n";




//$input = new NumericInput();
//$input->add('1');
//$input->add('a');
//$input->add('532');
//echo $input->getValue(); //print 1532